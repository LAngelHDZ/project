/**
 * @license Highcharts JS v8.0.0 (2019-12-10)
 * @module highcharts/themes/skies
 * @requires highcharts
 *
 * (c) 2009-2019 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../themes/skies.js';
