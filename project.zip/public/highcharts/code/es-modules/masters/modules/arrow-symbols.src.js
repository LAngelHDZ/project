/**
 * @license Highcharts JS v8.0.0 (2019-12-10)
 * @module highcharts/modules/arrow-symbols
 * @requires highcharts
 *
 * Arrow Symbols
 *
 * (c) 2017-2019 Lars A. V. Cabrera
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../parts-gantt/ArrowSymbols.js';
